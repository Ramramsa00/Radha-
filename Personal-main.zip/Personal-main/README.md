Welcome Dosto....
NON-DRM bot made by @oye_brijesh (TELEGRAM & Instagram)

#command
```
/start start the bot
/stop stop the bot
/logs to see bot logs
/cookies to update YouTube cookies
Direct send link
```
Direct Deploy via click these button 

## Deploy to Heroku

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://www.github.com/nikhilsaini098/Saini-txt-direct)

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy?repo=https://github.com/nikhilsaini098/Saini-txt-direct)

[![Deploy to Koyeb](https://www.koyeb.com/static/images/deploy/button.svg)](https://app.koyeb.com/deploy?name=saini-txt-direct&repository=nikhilsaini098%2FSaini-txt-direct&branch=main&instance_type=free&instances_min=0)
