#🇳‌🇮‌🇰‌🇭‌🇮‌🇱‌
# Add your details here and then deploy by clicking on HEROKU Deploy button
import os

API_ID    = os.environ.get("API_ID", "20214509")
API_HASH  = os.environ.get("API_HASH", "be3a4b6da22a66db83995afc70a733a1")
BOT_TOKEN = os.environ.get("BOT_TOKEN", "") 

#WEBHOOK = True  # Don't change this
#PORT = int(os.environ.get("PORT", 8080))  # Default to 8000 if not set
